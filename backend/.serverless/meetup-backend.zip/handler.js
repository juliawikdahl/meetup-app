'use strict';

const express = require('express');
const serverless = require('serverless-http');

const app = express();

// Middleware
app.use(express.json());
app.use(require('cors')());

// Dummy endpoint for testing
app.get('/hello', (req, res) => {
    res.json({ message: 'Hello from the Serverless backend!' });
});

// Additional routes
// Define your API routes here

// Export the app as a lambda function
module.exports.handler = serverless(app);
