// models/User.js
const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB.DocumentClient();

const User = {
    createUser: async (userData) => {
        const params = {
            TableName: 'Users',
            Item: {
                email: userData.email,
                password: userData.password,
                createdAt: new Date().toISOString(),
            },
        };
        return await dynamoDB.put(params).promise();
    },
    getUserByEmail: async (email) => {
        const params = {
            TableName: 'Users',
            Key: { email },
        };
        const result = await dynamoDB.get(params).promise();
        return result.Item;
    },
};

module.exports = User;
