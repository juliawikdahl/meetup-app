// models/Meetup.js
const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');
const dynamoDB = new AWS.DynamoDB.DocumentClient();

const Meetup = {
    createMeetup: async (meetupData) => {
        const params = {
            TableName: 'Meetups',
            Item: {
                id: uuidv4(), // Generera ett unikt ID
                title: meetupData.title, // Använd title istället för name
                date: meetupData.date,
                location: meetupData.location,
                description: meetupData.description,
                attendees: [], // Tom lista för anmälningar
                createdAt: new Date().toISOString(), // Tidpunkt för skapande
            },
        };
        return await dynamoDB.put(params).promise();
    },
    getAllMeetups: async () => {
        const params = {
            TableName: 'Meetups',
        };
        const result = await dynamoDB.scan(params).promise();
        return result.Items; // Returnera alla meetups
    },
    getMeetupById: async (id) => {
        const params = {
            TableName: 'Meetups',
            Key: { id }, // Sök med ID
        };
        const result = await dynamoDB.get(params).promise();
        return result.Item; // Returnera den specifika meetuppen
    },
    registerUser: async (meetupId, userEmail) => {
        const params = {
            TableName: 'Meetups',
            Key: { id: meetupId },
            UpdateExpression: 'SET attendees = list_append(attendees, :userEmail)',
            ExpressionAttributeValues: {
                ':userEmail': [userEmail], // Lägg till användarens email
            },
        };
        return await dynamoDB.update(params).promise();
    },
    unregisterUser: async (meetupId, userEmail) => {
        const params = {
            TableName: 'Meetups',
            Key: { id: meetupId },
            UpdateExpression: 'DELETE attendees :userEmail',
            ExpressionAttributeValues: {
                ':userEmail': userEmail, // Ta bort användarens email
            },
        };
        return await dynamoDB.update(params).promise();
    },
    searchMeetups: async (query) => {
        const params = {
            TableName: 'Meetups',
            FilterExpression: 'contains(#title, :query) OR contains(description, :query)',
            ExpressionAttributeNames: {
                '#title': 'title', // Använd alias för title
            },
            ExpressionAttributeValues: {
                ':query': query,
            },
        };
        const result = await dynamoDB.scan(params).promise();
        return result.Items; // Returnera de hittade meetups
    },
};

module.exports = Meetup;
