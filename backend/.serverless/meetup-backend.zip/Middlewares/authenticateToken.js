const authenticateToken = (req, res, next) => {
    const token = req.headers['authorization']?.split(' ')[1];

    if (!token) {
        console.log("Ingen token tillhandahållen");
        return res.sendStatus(401);
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) {
            console.log("Ogiltig token");
            return res.sendStatus(403);
        }
        console.log("Token verifierad, användare:", user);
        req.user = user; // Spara användarinformation
        next();
    });
};


module.exports = authenticateToken;
